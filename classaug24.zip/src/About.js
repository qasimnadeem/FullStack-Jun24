import './About.css'
function About() {
    const itemStyle= {minHeight:'500px',color:'red'}
    return (
      <>
        
        <h1 style={{color:"red",backgroundColor:"yellow"}}>About Page</h1>
        <p className="para">lore ipsum dolor sit amet right</p>
        <p className="txt-align">Good to Go</p>
        <p style={itemStyle}>lore ipsum dolor sit amet right</p>
        
      </>
    );
  }
  
  export default About;