function Home() {
    return (
      <>
        <h1>Home Page</h1>
        <p>lore ipsum dolor sit amet right</p>
      
      </>
    );
  }
  
  export default Home;