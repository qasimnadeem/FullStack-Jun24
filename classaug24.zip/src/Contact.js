import style from './Contact.module.css'
function Contact() {
    return (
      <>
        <h1>Contact Page</h1>
        <p className={style.txtAlign}>lore ipsum dolor sit amet right</p>
      
      </>
    );
  }
  
  export default Contact;